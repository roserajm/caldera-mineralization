## Written by Josh Rosera and submitted for publication in Geological Society of America Bulletin

# Load libraries
library(scales)
library(maptools)
library(spatstat)

# Set up working folder
setwd("~/Rosera_Coleman_files")

## Read in data from shapefiles (from ArcGIS 10.5)

  # Shapefile of study area:
  study.area = readShapeSpatial("StudyArea.shp")

  # Shapefile with caldera compilation:
  calderas = readShapeSpatial('calderas.shp')

  # Fishnet grid of 2.5 x 2.5 km cells was created in ArcGIS and centroids were extracted.
  fishnet.centers = readShapeSpatial('FishnetCenters.shp')
##
  
# Define window for SpatStat:
  W = as.owin(study.area)
  
# Load calderas and clip to study area
  C = as.psp(calderas)
  C = clip.psp(C,W)

## Function to snap to grid Centroids 
  SnapCentroids = function(x,y=fishnet.centers){
    x_ppp = as.ppp(x)
    y_ppp = as.ppp(y)
    nearest_y_from_x = nncross(x_ppp, y_ppp)
    x_new_coords = y_ppp[ nearest_y_from_x$which, ]
    x_new = as.SpatialPoints.ppp(x_new_coords)
    x_new
  }
##

#### Proximity analysis
  # Setup for generating random points
  set.seed(2019)

  rand.nn = 0
  breaks = seq(0, 1000, 2.5)
  rand.store = matrix(rep(0, (length(breaks)-1)*100), nrow = length(breaks)-1)
  rownames(rand.store) = breaks[-length(breaks)]

  # Generate random points with random Poisson point process
  # Pass through nearest neighbor analysis
  for (i in c(1:100)){
    rand.pois = rpoispp(24000/area(W), win = W)
    rand.pois = SnapCentroids(rand.pois)
    rand.pois = as.ppp(rand.pois)
    rand.pois = unique(rand.pois)
    rand.nn = nncross(rand.pois, C, what = 'dist')/1000
    counts = hist(rand.nn, breaks = breaks, plot = FALSE)$counts
    
    rand.store[,i] = counts
  }
  
  # For random frequency data
  rand.store.freq = 0*rand.store

  for(i in c(1:100)){
    rand.store.freq[,i] = 100*rand.store[,i]/sum(rand.store[,i])
  }

  # Summary statistics
  rand.av = apply(rand.store, 1, mean)
  rand.sd = apply(rand.store, 1, sd)

  ## On average, 11.5% of randomly located points fall within 10 km of a caldera rim
  sum(100*rand.av[c(1:4)]/sum(rand.av))

  ## Primary-only Proximity Analysis
   # Import x, y, and mark data. Generated from ArcGIS
   x.primary = read.csv('Primary_R_input.csv', header = TRUE)
  
    # Setup for SpatStat tools
    x.primary = ppp(x.primary$X, x.primary$Y, window = W, marks = x.primary$CODE)
    x.primary = unique(x.primary)  #remove duplicated points
    unitname(x.primary) = c("meter", "meters")
    
    x.primary.split = split(x.primary, as.factor(x.primary$marks))
    
    primary.list = c('AU', 'CU', 'PB', 'AG', 'W', 'MN', 'F','U', 'FE', 'HG', 'SB', 'ZN', 'BE', 'MO', 'AL', 'AS', 'BI')
    
    prime.store = matrix(rep(0, (length(breaks)-1)*length(primary.list)), nrow = length(breaks)-1)
    colnames(prime.store) = primary.list
    rownames(prime.store) = breaks[-length(breaks)]
      
    for (i in c(1:length(primary.list))){
      prime.x = x.primary[which(x.primary$marks == primary.list[i])]
      prime.x = SnapCentroids(prime.x)
      prime.x = as.ppp(prime.x)
      prime.x = unique(prime.x)
      prime.nn = nncross(prime.x, C, what = 'dist')/1000
      counts = hist(prime.nn, breaks = breaks, plot = FALSE)$counts
      
      prime.store[,i] = counts
    }
  ##

  ## Multi-commodity proximity analysis
    # Import x, y, and mark data
    x.multi = read.csv('Multi_R_input.csv')
    
    # Setup for SpatStat
    x.multi = ppp(x.multi$X, x.multi$Y, window = W, marks = x.multi$CODE)
    x.multi = unique(x.multi)  #remove duplicated points
    unitname(x.multi) = c("meter", "meters")
    
    list.multi = c('AU', 'AG', 'CU', 'PB', 'ZN', 'W', 'U', 'FE', 'MN', 'MO', 'HG', 'F', 'SB', 'BE', 'V', 'AS', 'REE', 'TH', 'AL', 'BI', 'MG', 'NB', 'SN', 'S', 'NI', 'LI')
    
    multi.store = matrix(rep(0, (length(breaks)-1)*length(list.multi)), nrow = length(breaks)-1)
    colnames(multi.store) = list.multi
    rownames(multi.store) = breaks[-length(breaks)]
    
    multi.store.remove = multi.store
    
    for (i in c(1:length(multi.store))){
      multi.x = x.multi[which(x.multi$marks == list.multi[i])]
      multi.x = SnapCentroids(multi.x)
      multi.x = as.ppp(multi.x)
      multi.x = unique(multi.x)
      multi.nn = nncross(multi.x, C, what = 'dist')/1000
      counts = hist(multi.nn, breaks = breaks, plot = FALSE)$counts
    
      multi.store[,i] = counts
    }
  ##
  
  #### This code calculates the frequency for each analysis
  #### then creates the frequency-distance plots and correspondence symmetric maps

    #Calculate frequency for each
      prime.store.freq = 0*prime.store
      for(i in c(1:dim(prime.store)[2])){
        prime.store.freq[,i] = 100*prime.store[,i]/sum(prime.store[,i])
      }
      colnames(prime.store.freq) = primary.list
  
      multi.store.freq = 0*multi.store
      for(i in c(1:dim(multi.store)[2])){
        multi.store.freq[,i] = 100*multi.store[,i]/sum(multi.store[,i])
      }
      colnames(multi.store.freq) = list.multi
    #

  ### Frequency-distance plots
   #set up colors
      FrPal = colorRampPalette(c('firebrick2', 'orange', 'blue', 'light blue', 'gray40', 'gray70'), alpha = TRUE)
      
      col.Au = rgb(254,153,51, maxColorValue = 255)
      col.Cu = rgb(45,175,74, maxColorValue = 255)
      col.Pb = rgb(255,65,0, maxColorValue = 255)
      col.Ag= rgb(33,113,181, maxColorValue = 255)
      col.W= rgb(0,112,255, maxColorValue = 255)
      col.F= rgb(152,36,163, maxColorValue = 255)
      col.Mn= rgb(240,2,127, maxColorValue = 255)
      
      mCol = c(col.Au, col.Cu, col.Pb, col.Ag, col.W, col.Mn, col.F, "black", "gray40", "orange", "black", "brown","black","red")
      mCol123 = c(col.Au, col.Ag, col.Cu, col.Pb, "brown", col.W, "black", "gray40", col.Mn, "red", "orange", col.F)

    ## Easier to plot upper limit of bins in this case
      seq = as.numeric(row.names(prime.store)) + 2.5
      Lab123 = colnames(multi.store)

  ## Figure 2
     par(mfrow=c(3,2),mar = c(0,0,0,0), oma = c(5,4,5,2))
  
    # FIRST ROW: Au-Ag-Pb-Zn, or ~ epithermal deposits ###
      plot(seq, 100*rand.av/sum(rand.av), type = 'n', log = 'x', axes = FALSE, xlab = "Distance from nearest caldera rim (km)", ylab = "Frequency (%)", ylim = c(0,15), xlim = c(2.5,200))
      for (i in c(1:100)){
        lines(seq, rand.store.freq[,i], col = alpha('gray80', .5))
      }
      for(i in c(c(3,4,1))){
        lines(seq, 100*(prime.store[,i]/sum(prime.store[,i])), col = alpha(mCol[i],.65), lwd=2)
      }
      # Dashed Zn because it has lower total abundance than the others
      lines(seq, 100*(prime.store[,12]/sum(prime.store[,12])), col = alpha(mCol[12],.65), lwd=1, lty = 3)
      axis(side =2, tck = 0.01)
      box()
      
      plot(seq, 100*rand.av/sum(rand.av), type = 'n', log = 'x', axes = FALSE, xlab = "Distance from nearest caldera rim (km)", ylab = "Frequency (%)", ylim = c(0,15), xlim = c(2.5,200))
      for (i in c(1:100)){
        lines(seq, rand.store.freq[,i], col = alpha('gray80', .5))
      }
      for(i in c(c(1,2,4,5))){
        lines(seq, 100*(multi.store[,i]/sum(multi.store[,i])), col = alpha(mCol123[i],.65), lwd=2)
      }
      box()
      legend('topright', legend =c(Lab123[c(1,2,4,5)], "Random"), col = alpha(c(mCol123[c(1,2,4,5)], 'gray50'), .65), lwd = c(2,2,2,1))
  
  
    # Second Row: Cu-Mo-W-Fe, or ~ porphyry/skarn deposits ###
      plot(seq, 100*rand.av/sum(rand.av), type = 'n', log = 'x', axes = FALSE, xlab = "Distance from nearest caldera rim (km)", ylab = "Frequency (%)", ylim = c(0,15), xlim = c(2.5,200))
      for (i in c(1:100)){
        lines(seq, rand.store.freq[,i], col = alpha('gray80', .5))
      }
      # Dashed due to lower abundance
      for(i in c(c(9,14))){
        lines(seq, 100*(prime.store[,i]/sum(prime.store[,i])), col = alpha(mCol[i],.65), lwd=1, lty = 3)
      }
      # CU
      lines(seq, 100*(prime.store[,2]/sum(prime.store[,2])), col = alpha(mCol[2],.65), lwd=2)
      # W
      lines(seq, 100*(prime.store[,5]/sum(prime.store[,5])), col = alpha(mCol[5],.65), lwd=2)
      axis(side =2, tck = 0.01)
      box()
      
      plot(seq, 100*rand.av/sum(rand.av), type = 'n', log = 'x', axes = FALSE, xlab = "Distance from nearest caldera rim (km)", ylab = "Frequency (%)", ylim = c(0,15), xlim = c(2.5,200))
      for (i in c(1:100)){
        lines(seq, rand.store.freq[,i], col = alpha('gray80', .5))
      }
      for(i in c(c(3,10,6,8))){
        lines(seq, 100*(multi.store[,i]/sum(multi.store[,i])), col = alpha(mCol123[i],.65), lwd=2)
      }
      box()
      legend('topright', legend =c(Lab123[c(3,10,6,8)], "Random"), col = alpha(c(mCol123[c(3,10,6,8)], 'gray50'), .65), lwd = c(2,2,2,1))
  
    ## row 3 
      plot(seq, 100*rand.av/sum(rand.av), type = 'n', log = 'x', axes = FALSE, xlab = "Distance from nearest caldera rim (km)", ylab = "Frequency (%)", ylim = c(0,15), xlim = c(2.5,200))
      for (i in c(1:100)){
        lines(seq, rand.store.freq[,i], col = alpha('gray80', .5))
      }
      
      ### Mn, F, U
      for(i in c(c(7,8, 10))){
        lines(seq, 100*(prime.store[,i]/sum(prime.store[,i])), col = alpha(mCol[i],.65), lwd=1, lty = 3)
      }
      
      for(i in c(c(6))){
        lines(seq, 100*(prime.store[,i]/sum(prime.store[,i])), col = alpha(mCol[i],.65), lwd=2)
      }
      axis(side = 2, tck = 0.01)
      axis(side = 1, tck = 0.01)
      box()
      
      plot(seq, 100*rand.av/sum(rand.av), type = 'n', log = 'x', axes = FALSE, xlab = "Distance from nearest caldera rim (km)", ylab = "Frequency (%)", ylim = c(0,15), xlim = c(2.5,200))
      for (i in c(1:100)){
        lines(seq, rand.store.freq[,i], col = alpha('gray80', .5))
      }
      
      for(i in c(c(7,9,11,12))){
        lines(seq, 100*(multi.store[,i]/sum(multi.store[,i])), col = alpha(mCol123[i],.65), lwd=2)
      }
      axis(side = 1, tck = 0.01)
      box()
      
      legend('topright', legend =c(Lab123[c(7,9,11,12)], "Random"), col = alpha(c(mCol123[c(7,9,11,12)], 'gray50'), .65), lwd = c(2,2,2,1))
  
      mtext("Frequency (%)" , side = 2, outer = TRUE, line = 2, cex = 1.2)
      mtext("Distance from nearest caldera rim (km, log scale)", side = 1, outer = TRUE, line = 3, cex = 1.2)
  ## End frequency-distribution plots

    
#### Correspondence Analysis ##########

## Primary-only
  # Rename output from proximity analysis:
  z = prime.store[c(1:140),]
  
  #Set up correspondence matrix
  Pz = as.matrix(z/sum(z))
  
  #Row and column masses:
  Rzi = apply(Pz, 1, sum)
  Czi = apply(Pz, 2, sum)
  
  #Diagonal matrices of row and column masses
  Dzr = diag(Rzi)
  Dzc = diag(Czi)
  
  #inverse square root of diagonal matrix, where off-diagonal remains 0:
  Dzrs = diag(1/sqrt(diag(Dzr)))
  Dzcs = diag(1/sqrt(diag(Dzc)))
  ## a few 0's in denominator need to be set back to 0:
  Dzrs[is.infinite(Dzrs)] = 0
  Dzcs[is.infinite(Dzcs)] = 0
  
  ### Calculate the S matrix (A.4 in Greenacre)
  Sz = Dzrs %*% (Pz - Rzi %*% t(Czi)) %*% Dzcs
  
  # Decompose S with SVD:
  Szsvd = svd(Sz)
  Uz = Szsvd$u
  Vz = Szsvd$v
  Dza = diag(Szsvd$d)
  Dzl = diag(1/sqrt(Szsvd$d))
  
  #std coordinates, phi, of rows (A.6 Greenacre)
  phiz = Dzrs %*% Uz
  
  # std coordinates gam of columns:
  gamz = Dzcs %*% Vz
  
  #principal coordinates F of rows:
  Frz = phiz %*% Dza
  
  #principal coordinates Gc of columns (A.9):
  Gcz = gamz %*% Dza
  Gz = solve(Dzcs) %*% t(Pz) %*% Frz %*% Dzl
  
  #plot of principal intertias, lamk:
  lamkz = (Szsvd$d)^2
  
  #first component is 21.3%, second is 11.3 percent
  round(cumsum(lamkz[1:length(lamkz)])/sum(lamkz[1:length(lamkz)]), 3) *100
  # barplot of above
    barplot(100*lamkz/sum(lamkz), names.arg = c(1:length(lamkz)), xlab = "Principal inertias", ylab = "%")
  
  #color given to last column, which is insignificant anyway
  breaks.ca= c(0, 10000, seq(20000,100000,20000),350000)
  Frz[,17] = as.numeric(cut(seq[c(1:140)]*1000,breaks=breaks.ca))
  pCol = c("red", "orange", "yellow", "green", "cadetblue", "light blue", "gray50")
  
  
## Multi-commodity 
  #Rename multi-commodity proximity results:
  z123 = multi.store[c(1:140),]
  
  #Set up correspondence matrix
  Pz123 = as.matrix(z123/sum(z123))
  
  #Row and column masses:
  Rzi123 = apply(Pz123, 1, sum)
  Czi123 = apply(Pz123, 2, sum)
  
  #Diagonal matrices of row and column masses
  Dzr123 = diag(Rzi123)
  Dzc123 = diag(Czi123)
  
  #inverse square root of diagonal matrix, where off-diagonal remains 0:
  Dzrs123 = diag(1/sqrt(diag(Dzr123)))
  Dzcs123 = diag(1/sqrt(diag(Dzc123)))
  ## a few 0's in denominator need to be set back to 0:
  Dzrs123[is.infinite(Dzrs123)] = 0
  Dzcs123[is.infinite(Dzcs123)] = 0
  
  ### Calculate the S matrix (A.4 in Greenacre)
  Sz123 = Dzrs123 %*% (Pz123 - Rzi123 %*% t(Czi123)) %*% Dzcs123
  
  # Decompose S with SVD:
  Szsvd123 = svd(Sz123)
  Uz123 = Szsvd123$u
  Vz123 = Szsvd123$v
  Dza123 = diag(Szsvd123$d)
  Dzl123 = diag(1/sqrt(Szsvd123$d))
  
  #std coordinates, phi, of rows (A.6 Greenacre)
  phiz123 = Dzrs123 %*% Uz123
  
  # std coordinates gam of columns:
  gamz123 = Dzcs123 %*% Vz123
  
  #principal coordinates F of rows:
  Frz123 = phiz123 %*% Dza123
  
  #principal coordinates Gc of columns (A.9):
  Gcz123 = gamz123 %*% Dza123
  Gz123 = solve(Dzcs123) %*% t(Pz123) %*% Frz123 %*% Dzl123
  
  #plot of principal intertias, lamk:
  lamkz123 = (Szsvd123$d)^2
  
  #first component is 12.3%, second is 11.4
  #barplot(100*lamkz123/sum(lamkz123), names.arg = c(1:length(lamkz123)), xlab = "Principal inertias", ylab = "%")
  round(cumsum(lamkz123[1:length(lamkz123)])/sum(lamkz123[1:length(lamkz123)]), 3) *100
  
  #color given to last column, which is insignificant anyway
  Frz123[,26] = as.numeric(cut(seq[c(1:140)]*1000,breaks=breaks.ca))

### Figure 3; CA results 
  op = par(mfrow = c(1,1))
  par(mfrow = c(2,2),mar = c(0,0,0,0), oma = c(5,4,4,2), bg = 'white')
  
  labZ = colnames(prime.store)
  
  plot(as.numeric(Frz[,1]), as.numeric(Frz[,2]), axes = FALSE,type = 'n', pch = 20, cex = 2, xlim=c(-0.5,1.5))
  abline(v = 0, h = 0, lty = 2, lwd = 0.5, col = 'gray60')
  points(Gcz[,1], Gcz[,2], pch = 0, col = 'gray30', cex = .8)
  text(Gcz[,1], Gcz[,2], labels = labZ, col = 'gray30', pos = 3, cex = 0.8, font = 2)
  for(i in rev(c(1,c(1:max(Frz[,17]))))){
    points(as.numeric(Frz[Frz[,17]==i,1]), as.numeric(Frz[Frz[,17]==i,2]), pch = 20, col = alpha(pCol[i],.45), cex = 1.2)
  }
  axis(side = 2, tck = 0.01)
  axis(side = 3, tck = 0.01)
  box()
  
  rect(xleft = -.5, ybottom =-.7, xright = 0.5, ytop = .5, border = 'gray80', lty= 3)
  
  plot(as.numeric(Frz[,1]), as.numeric(Frz[,2]), axes = FALSE, type = 'n', xlim = c(-.5,.5), ylim = c(-.7,.5))
  rect(-1,-1,1,1, col = "white", border = "black")
  abline(v = 0, h = 0, lty = 2, lwd = 0.5, col = 'gray60')
  points(Gcz[,1], Gcz[,2], pch =0, col = 'gray40', cex = .8)
  text(Gcz[,1], Gcz[,2], labels = labZ, col = 'gray30', pos = 3, cex = 0.8, font = 2)
  for(i in rev(c(1,c(1:max(Frz[,17]))))){
    points(as.numeric(Frz[Frz[,17]==i,1]), as.numeric(Frz[Frz[,17]==i,2]), pch = 20, col = alpha(pCol[i],.45), cex = 1.2)
  }
  axis(side = 4, tck = 0.01)
  axis(side = 3, tck = 0.01)
  box()
  
  # Second row
  labZ123 = colnames(multi.store)
  
  plot(as.numeric(Frz123[,1]), as.numeric(Frz123[,2]), axes = FALSE, xlim = c(-4.5,0.5),ylim=c(-3.5,3),type = 'n', pch = 20, cex = 2, xlab = "Correspondence Axis 1", ylab = "Correspondence Axis 2")
  abline(v = 0, h = 0, lty = 2, lwd = 0.5, col = 'gray60')
  points(Gcz123[,1], Gcz123[,2], pch = 0, col = 'gray40', cex = .8)
  text(Gcz123[,1], Gcz123[,2], labels = labZ123, col = 'gray30', pos = 3, cex = 0.8)
  for(i in rev(c(1,c(1:max(Frz123[,26]))))){
    points(as.numeric(Frz123[Frz123[,26]==i,1]), as.numeric(Frz123[Frz123[,26]==i,2]), pch = 1, col = alpha(pCol[i],.75), cex = 0.8)
  }
  axis(side = 2, tck = 0.01)
  axis(side = 1, tck = 0.01)
  box()
  
  rect(xleft = -.4, ybottom =-.6, xright = 0.4, ytop = .6, border = 'gray80', lty= 3)
  
  plot(as.numeric(Frz123[,1]), as.numeric(Frz123[,2]), axes = FALSE, type = 'n', xlim = c(-.4,.4), ylim = c(-.6,.6))
  rect(-1,-1,1,1, col = "white", border = "black")
  abline(v = 0, h = 0, lty = 2, lwd = 0.5, col = 'gray60')
  points(Gcz123[,1], Gcz123[,2], pch = 0, col = 'gray40', cex = .8)
  text(Gcz123[,1], Gcz123[,2], labels = labZ123, col = 'gray30', pos = 3, cex = 0.8, font = 2)
  for(i in rev(c(1,c(1:max(Frz123[,26]))))){
    points(as.numeric(Frz123[Frz123[,26]==i,1]), as.numeric(Frz123[Frz123[,26]==i,2]), pch = 1, col = alpha(pCol[i],.75), cex = .8)
  }
  axis(side = 4, tck = 0.01)
  axis(side = 1, tck = 0.01)
  box()
### End plots for Figure 3

#### Barplots for Figure 4
  # Sort caldera by OID, set up a dataframe to store the info, use barplots from there
  bar.df = seq(1,243, by = 1)
  bar.zero = rep(0, length(bar.df))
  bar.df = cbind(bar.df, bar.zero, bar.zero, bar.zero, bar.zero, bar.zero)
  colnames(bar.df) = c("ID", "Ag", "Pb", "Zn", "F", "Hg")
  
  # Select primary-only Ag, use Snap to remove over sampling
  bar.ag = x.primary[which(x.primary$marks == 'AG')]
  bar.ag = SnapCentroids(bar.ag)
  bar.ag = as.ppp(bar.ag)
  bar.ag = unique(bar.ag)
  
  # Use nncross to extract those within 10 km of a caldera
  ag.cross = nncross(bar.ag, C)
  ag.10km = ag.cross$which[ag.cross$dist <= 10000]
  ## summarize many features to single caldera OIDs:
  ag.table = table(C$marks[ag.10km])
  
  # Repeat for primary-only Pb
  bar.pb = x.primary[which(x.primary$marks == 'PB')]
  bar.pb = SnapCentroids(bar.pb)
  bar.pb = as.ppp(bar.pb)
  bar.pb = unique(bar.pb)
  pb.cross = nncross(bar.pb, C)
  pb.10km = pb.cross$which[pb.cross$dist <= 10000]
  pb.table = table(C$marks[pb.10km])
  
  # Repeat for multi-commodity Zn
  bar.zn = x.multi[which(x.multi$marks == 'ZN')]
  bar.zn = SnapCentroids(bar.zn)
  bar.zn = as.ppp(bar.zn)
  bar.zn = unique(bar.zn)
  zn.cross = nncross(bar.zn, C)
  zn.10km = zn.cross$which[zn.cross$dist <= 10000]
  zn.table = table(C$marks[zn.10km])
  
  # Repeat for multi-commodity F
  bar.F = x.multi[which(x.multi$marks == 'F')]
  bar.F = SnapCentroids(bar.F)
  bar.F = as.ppp(bar.F)
  bar.F = unique(bar.F)
  F.cross = nncross(bar.F, C)
  F.10km = F.cross$which[F.cross$dist <= 10000]
  F.table = table(C$marks[F.10km])
  
  # Finally, for Hg
  bar.hg = x.multi[which(x.multi$marks == 'HG')]
  bar.hg = SnapCentroids(bar.hg)
  bar.hg = as.ppp(bar.hg)
  bar.hg = unique(bar.hg)
  hg.cross = nncross(bar.hg, C)
  hg.10km = hg.cross$which[hg.cross$dist <= 10000]
  hg.table = table(C$marks[hg.10km])
  
  # Extract OIDs from caldera file (originally defined in Shapefile)
  cald.ID = table(C$marks)
  
  # Store above tables into dataframe for barplot:
  bar.df[bar.df[,1] %in% as.numeric(names(ag.table)),2] = ag.table
  bar.df[bar.df[,1] %in% as.numeric(names(pb.table)),3] = pb.table
  bar.df[bar.df[,1] %in% as.numeric(names(zn.table)),4] = zn.table
  bar.df[bar.df[,1] %in% as.numeric(names(F.table)),5] = F.table
  bar.df[bar.df[,1] %in% as.numeric(names(hg.table)),6] = hg.table
  
  # There are more placeholders for ID in the bar dataframe than there are actual caldera OIDs
  # This removes those placeholders
  bar.df = bar.df[bar.df[,1] %in% as.numeric(names(cald.ID)),] 
  
  # These are the calderas that have either primary Ag-Pb or by-product Zn-F-Hg within 10 km
  age.10km.calderas = calderas$AGE_MA[calderas$OBJECTID %in% bar.df[,1]]
  name.10km.calderas = calderas$NAME[calderas$OBJECTID %in% bar.df[,1]]
  name.10km.calderas = name.10km.calderas[order(age.10km.calderas)]
  
  # Recast with age as first column:
  bar.df.age = cbind(age.10km.calderas, bar.df[,c(2:6)])
  bar.df.age = bar.df.age[order(age.10km.calderas),]
  
  # For old color version
  #bar.col = c(col.Ag, col.Pb, "brown", col.F, "orange")
  
  # Unmineralized = calderas with none of these deposits within 10 km 
  unmineralized = rep("", 149)
  # Just set up a flag:
  unmineralized[which(apply(bar.df.age[c(6:154),c(2:6)], 1, sum) == 0)] = "-"
  
  ## Create the plot
  par(mfrow = c(1,6), mar = c (0,1,0,0), oma = c(2.5,1,0,2))
  first = barplot(rev(bar.df.age[c(6:154),2]), cex.axis = 1.5, las = 1, border = NA, horiz = TRUE, col = 'black')
  axis(2, at = first, labels = rep("", 149, tcl = 0.05), col = 'gray50')
  for (i in c(2:5)){ 
    barplot(rev(bar.df.age[c(6:154),1+i]), horiz = TRUE, col = 'black', cex.axis = 1.5, border = NA)
    axis(2, at = first, labels = rep("", 149, tcl = 0.05), col = 'gray50')
  }
  
  barplot(bar.df.age[c(6:154),2]*0, names.arg = rev(unmineralized), las = 1, axes = FALSE, horiz = TRUE, cex.names = 2.5)
  
  ## Use this to see the caldera names, too 
  #barplot(bar.df.age[c(6:154),2]*0, names.arg = rev(name.10km.calderas[c(6:154)]), las = 1, horiz = TRUE, col = alpha(bar.col[1], .65))
  ## 